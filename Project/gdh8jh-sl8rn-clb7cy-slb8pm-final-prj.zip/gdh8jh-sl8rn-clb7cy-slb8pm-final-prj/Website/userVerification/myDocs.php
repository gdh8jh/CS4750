<?php
session_start(); // start session
require('connectdbUser.php'); // connect to database
$user = $_SESSION['User'];

global $db;

// activates when user deletes document
if (isset($_POST['Delete'])) {

    // call SQL delete code. Deletes document informatino from both document and technical_info table as they are connected (document always goes first in this case)
    $sql = 'DELETE FROM document WHERE docName = "' . $_POST['docToDelete'] . '" AND fileID = ' . $_POST['fileIDToDelete'];
    $result = $db->query($sql);


    $sql = 'DELETE FROM technical_info WHERE fileID = ' . $_POST['fileIDToDelete'];
    $result = $db->query($sql);


}

// performs select statement in order to generate table of document information that user submitted. this is used later on in html code
$sql = 'SELECT docName, fileID, userEmail, courseID, subject, type, numCards, maxScore from document WHERE userEmail = "' . $user . '"';
$result = $db->query($sql);
 


?>


<!-- HTML CODE -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="your name">
    <meta name="description" content="include some description about your page">
    <title>DB interfacing</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <style>
        div {
            margin-bottom: 10px;
        }

        label {
            display: inline-block;
            width: 150px;
            text-align: right;
        }
    </style>

    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="docUpload.php">Upload</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="feedback.php">Feedback</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="search.php">Search</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="myDocs.php">MyFiles</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="login.php">Log Out</a>
            </li>
        </ul>
        <p style="color:silver" class="navbar-nav"> Current User: <?php echo $user ?> </p>
    </nav>

</head>

<body>
    <div class="container">

        <h1>My Documents</h1>

        <!-- Table that displays user document information -->
        <table class="w3-table w3-bordered w3-card-4 center" style="width:70%">
            <thead>
                <tr style="background-color:#B0B0B0">
                    <th width="25%">Document</th>
                    <th width="25%">Owner</th>
                    <th width="25%">CourseID</th>
                    <th width="25%">Subject</th>
                    <th width="25%">Type</th>
                    <th width="25%">Cards</th>
                    <th width="25%">Max Score</th>
                    <th width="25%">Delete</th>
                </tr>
            </thead>

            <?php

           
            // displays information from document table in database
            while ($row = $result->fetch()) {
                echo "<tr><td>" . $row["docName"] . "</td><td>" . $row["userEmail"] . "</td><td>" . $row["courseID"] . "</td><td>" . $row["subject"] . "</td><td>" . $row["type"] . "</td><td>" . $row["numCards"] . "</td><td>" . $row["maxScore"] . "</td>";
                echo "<td><form action=". $_SERVER['PHP_SELF'] .' method="post">';
                echo '<input type="submit" value="Delete" name="Delete" class="btn btn-danger" title="Permanently delete the record" />';
                echo '<input type="hidden" name="docToDelete" value="' . $row["docName"] . '" />'; // adds delete button as part of column
                echo '<input type="hidden" name="fileIDToDelete" value="' . $row["fileID"] . '" />';
                echo '</form>';
                echo '</td>';
                echo '</tr>';
            }

            ?>

</body>

</html>