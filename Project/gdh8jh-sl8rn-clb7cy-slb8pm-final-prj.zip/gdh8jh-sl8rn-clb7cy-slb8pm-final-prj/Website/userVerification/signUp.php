<?php
require('connectdb.php'); // conencts to database


$canSubmit = 1; // used to check to see if the user can sign up or not. 1 means yes and 0 means no
$email = ""; 
$password = "";
$errors = array(); // array used to hold error messages
$found = 1; // checks if information is found during a search. 1 means yes and 0 means no
$notErrors = array(); // array used to hold success messages

// actiavets when user hits the sign up button
if (isset($_POST['signup-btn'])) {

    // generates random support staff number so that they can be assigned to new user 
    $test = rand(1, 18);

    // checks if email field is empty
    if (empty($_POST['email'])) {
        $errors['email'] = "Email required";
        $canSubmit = 0;
    }

    // checks if passwords don't match
    if ($_POST['password'] != $_POST['passwordConf']) {
        $errors['email'] = "Passwords don't match";
        $canSubmit = 0;
    }

    $found = 0;

    // searches through database to check if user already exists
    global $db;
    $sql = "SELECT userEmail, password from users";
    $result = $db->query($sql);

    while ($row = $result->fetch()) {
        if ($row["userEmail"] == $_POST['email']) {
            $found = 1;
            break;
        }
    }



    // if user already exists in database then an error message is displayed
    if ($found == 1) {
        $errors['duplicate'] = "Sorry, this email already exists.";
        $canSubmit = 0;
    }


    // if user doesn't exist yet...
    if ($canSubmit == 1) {
        //inserts user into database
        $query = 'INSERT INTO users VALUES ("' . $_POST['email'] . '", "' . $_POST['password'] . '", ' . $test . ')';
        $statement = $db->query($query);

        // creates empty profile for user
        $query = 'INSERT INTO userprofiles (userEmail, major, DOB, compID, first_name, last_name)
        VALUES ("' . $_POST['email'] . '", NULL, NULL, NULL, NULL, NULL)';
        $statement = $db->query($query);

        // displays success message
        $notErrors['congrats'] = "Your account was successfully created.";

        // adds user as an official user to phpMyAdmin database (complete with privileges)
        $query = 'CREATE USER "' . $_POST['email'] . '"@"localhost" IDENTIFIED BY "' . $_POST['password'] . '"';
        $statement = $db->query($query);

        // grants privileges to user
        $query = 'GRANT SELECT, UPDATE ON studybuddy.userprofiles TO "' . $_POST['email'] . '"@"localhost"';
        $statement = $db->query($query);

        $query = 'GRANT DELETE, SELECT, INSERT ON studybuddy.technical_info TO "' . $_POST['email'] . '"@"localhost"';
        $statement = $db->query($query);

        $query = 'GRANT DELETE, SELECT, INSERT ON studybuddy.document TO "' . $_POST['email'] . '"@"localhost"';
        $statement = $db->query($query);

        $query = 'GRANT INSERT ON studybuddy.feedback TO "' . $_POST['email'] . '"@"localhost"';
        $statement = $db->query($query);

        $query = 'GRANT EXECUTE ON PROCEDURE studybuddy.storeFeedback to "' . $_POST['email'] . '"@"localhost"';
        $statement = $db->query($query);

    }
}
?>

<!-- HTML Code -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Register</title>

</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4 form-div">
                <form action="signUp.php" method="post">
                    <h3 class="text-center">Register</h3>

                    <!-- php code that iterively displays error messages when the user has submitted the form with problems-->
                    <?php if (count($errors) > 0) : ?>
                        <div class="alert alert-danger">
                            <?php foreach ($errors as $error) : ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <!-- php code that iterively displays error messages when the user has submitted form with NO problems-->
                    <?php if (count($notErrors) > 0) : ?>
                        <div class="alert alert-success">
                            <?php foreach ($notErrors as $notError) : ?>
                                <li><?php echo $notError; ?></li>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" name="email" class="form-control form-control-lg">
                    </div>

                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" class="form-control form-control-lg">
                    </div>

                    <div class="form-group">
                        <label for="passwordConf">Confirm Password</label>
                        <input type="password" name="passwordConf" class="form-control form-control-lg">
                    </div>

                    <div class="form-group">
                        <div class="form-group">
                            <button type="submit" name="signup-btn" class="btn btn-primary btn-block btn-lg">Sign Up</button>
                        </div>

                        <p class="text-center"> Already a member? <a href="login.php"> Sign In </a></p>

                </form>
            </div>
        </div>
    </div>

</body>

</html>