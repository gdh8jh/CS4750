<?php
session_start(); // starts session
require('connectdbUser.php'); // connects to database


$user = $_SESSION['User'];
$feed = "";
$adminID = 0;
$notErrors = array(); // array that contains list of success message texts

//activates when user submits the feedback form
if (isset($_POST['submitFeedback'])) {
    global $db;
    $adminID = rand(1, 20); // generates a random admin ID (number is between the least and greatest admin ID)
    $notErrors['congrats'] = "Your feedback was successfully submitted."; // let users know their message has been successfully submitted

    $query = 'CALL storeFeedback(' . $adminID . ', "'. $_POST['myFeed'] . '", "' .  $user . '")'; /// call stored procedure
    $statement = $db->query($query);
}
?>


<!-- HTML Code -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="your name">
    <meta name="description" content="include some description about your page">
    <title>DB interfacing</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">


    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="docUpload.php">Upload</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link"  href="feedback.php">Feedback</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="search.php">Search</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="myDocs.php">MyFiles</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="login.php">Log Out</a>
            </li>
        </ul>

        <p style="color:silver" class="navbar-nav"> Current User: <?php echo $user ?> </p>
    </nav>

</head>

<body>
    <div class="container">

        <h1>Feedback</h1>

        <!-- php code that iterively displays success messages when the user has submitted form -->
        <?php if (count($notErrors) > 0) : ?>
            <div class="alert alert-success">
                <?php foreach ($notErrors as $notError) : ?>
                    <li><?php echo $notError; ?></li>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- feedback form  -->
        <form name="mainForm" action="feedback.php" method="post">
            <div class="form-group">
                <label for="exampleFormControlTextarea1">Please give us your thoughts. What can we do better?</label>
                <textarea class="form-control" name="myFeed" id="exampleFormControlTextarea1" rows="10"></textarea>
            </div>

            <input type="submit" value="Submit Feedback" name="submitFeedback" class="btn btn-dark" title="Confirm update a friend" />

        </form>

</body>

</html>