<?php
// This file connects the logged in user to the database

// connecting to DB on XAMPP (local)

 $username = $_SESSION['User'];
 $password = $_SESSION['Password'];
 $host = 'localhost:3306';
 $dbname = 'studybuddy';


/******************************/
// connecting to DB on CS server

// $username = 'your-computingID';
// $password = 'your-mysql-password';
// $host = 'usersrv01.cs.virginia.edu';
// $dbname = 'your-computingID';


/******************************/

$dsn = "mysql:host=$host;dbname=$dbname";
$db = "";

/** connect to the database **/
try 
{
   $db = new PDO($dsn, $username, $password);   
   #echo "<p>You are connected to the database as a user</p>";
}
catch (PDOException $e)     // handle a PDO exception (errors thrown by the PDO library)
{
   // Call a method from any object, 
   // use the object's name followed by -> and then method's name
   // All exception objects provide a getMessage() method that returns the error message 
   $error_message = $e->getMessage();        
   echo "<p>An error occurred while connecting to the database: $error_message </p>";
}
catch (Exception $e)       // handle any type of exception
{
   $error_message = $e->getMessage();
   echo "<p>Error message: $error_message </p>";
}

?>