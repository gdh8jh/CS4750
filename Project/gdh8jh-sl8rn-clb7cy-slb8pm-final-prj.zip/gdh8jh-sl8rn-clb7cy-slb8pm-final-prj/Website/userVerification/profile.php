<?php
session_start(); // start session
require('connectdbUser.php'); // connect to database


$user = $_SESSION['User'];

// variables representing different values in the database
$major = "";
$DOB = "";
$compID = "";
$fName = "";
$lName = "";
$modded = 0; // checks to see if the profile is modified. 0 means not modified and 1 means modififed
$successMessages = array(); // array that holds success messages for later use

// select statement that checks to see what values in userprofiles table is null and what is not null (basically, it checks to see if user has entered their custom information into it yet)
// if user has not yet updated parts of their profile, then the filler text remains
global $db;
$sql = "SELECT userEmail, major, DOB, compID, first_name, last_name
        FROM userprofiles";
$result = $db->query($sql);

while ($row = $result->fetch()) {
  if ($row["userEmail"] == $user) {

    if (is_null($row["major"])) {
      $major = "Please type in major";
    } else {
      $major = $row["major"];
    }

    if (is_null($row["DOB"])) {
      $DOB = "Please type in DOB (yyyy-mm-dd format)";
    } else {
      $DOB = $row["DOB"];
    }

    if (is_null($row["compID"])) {
      $compID = "Please type in your computing ID";
    } else {
      $compID = $row["compID"];
    }

    if (is_null($row["first_name"])) {
      $fName = "Please type in first name";
    } else {
      $fName = $row["first_name"];
    }

    if (is_null($row["last_name"])) {
      $lName = "Please type in last name";
    } else {
      $lName = $row["last_name"];
    }

    break;
  }
}

// activates when profile is updated
// bottom code checks to see what parts of the profile were changed, and then updates the database accordingly
if (isset($_POST['profileUpdate'])) {

  $modded = 0;

  if ($_POST['major'] != "Please type in major") {
    $query = 'UPDATE userprofiles SET major = "' . $_POST['major'] . '" WHERE userEmail = "' . $user . '"';
    $major = $_POST['major'];
    $statement = $db->query($query);
    $modded = 1;
  }

  if ($_POST['DOB'] != "Please type in DOB (yyyy-mm-dd format)") {
    $query = 'UPDATE userprofiles SET DOB = "' . $_POST['DOB'] . '" WHERE userEmail = "' . $user . '"';
    $DOB = $_POST['DOB'];
    $statement = $db->query($query);
    $modded = 1;
  }

  if ($_POST['compID'] != "Please type in your computing ID") {
    $query = 'UPDATE userprofiles SET compID = "' . $_POST['compID'] . '" WHERE userEmail = "' . $user . '"';
    $compID = $_POST['compID'];
    $statement = $db->query($query);
    $modded = 1;
  }

  if ($_POST['fName'] != "Please type in first name") {
    $query = 'UPDATE userprofiles SET first_name = "' . $_POST['fName'] . '" WHERE userEmail = "' . $user . '"';
    $fName = $_POST['fName'];
    $statement = $db->query($query);
    $modded = 1;
  }

  if ($_POST['lName'] != "Please type in last name") {
    $query = 'UPDATE userprofiles SET last_name = "' . $_POST['lName'] . '" WHERE userEmail = "' . $user . '"';
    $lName = $_POST['lName'];
    $statement = $db->query($query);
    $modded = 1;
  }

  if ($modded == 1){
    $successMessages['m1'] = "Changes have been applied"; // if any of the profile is modified, then success message is added to success message array
  }

}


?>


<!-- HTML Code -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="author" content="your name">
  <meta name="description" content="include some description about your page">
  <title>DB interfacing</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">


  <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="profile.php">Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="docUpload.php">Upload</a>
            </li>
            <li class="nav-item">
                <a class="nav-link"  href="feedback.php">Feedback</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="search.php">Search</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="myDocs.php">MyFiles</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="login.php">Log Out</a>
            </li>
        </ul>
        <p style="color:silver" class="navbar-nav"> Current User: <?php echo $user ?> </p>
    </nav>

</head>

<body>
  <div class="container">

    <h1>My Profile</h1>

    <!-- If user has modified profile, then success messages are dispalyed -->
    <?php if (count($successMessages) > 0) : ?>
      <div class="alert alert-success">
        <?php foreach ($successMessages as $succesMessage) : ?>
          <li><?php echo $succesMessage; ?></li>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <form name="mainForm" action="profile.php" method="post">
      <div class="form-group">
        Major:
        <input type="text" class="form-control" value="<?php echo $major ?>" name="major" /> 
      </div>
      <div class="form-group">
        Date of Birth:
        <input type="text" class="form-control" value="<?php echo $DOB ?>" name="DOB" />
      </div>
      <div class="form-group">
        Computing ID:
        <input type="text" class="form-control" value="<?php echo $compID ?>" name="compID" />
      </div>
      <div class="form-group">
        First Name:
        <input type="text" class="form-control" value="<?php echo $fName ?>" name="fName" />
      </div>
      <div class="form-group">
        Last Name:
        <input type="text" class="form-control" value="<?php echo $lName ?>" name="lName" />
      </div>

      <input type="submit" value="Confirm Profile Update" name="profileUpdate" class="btn btn-dark" title="Confirm update a friend" />

    </form>

</body>

</html>