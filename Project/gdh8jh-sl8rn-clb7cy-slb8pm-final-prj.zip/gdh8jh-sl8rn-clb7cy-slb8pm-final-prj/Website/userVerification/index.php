<?php
session_start(); // starts session
$user = $_SESSION['User']; 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <title>Homepage</title>

    <!-- Navbar Location. Each navbar button sends user to different web page -->
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="docUpload.php">Upload</a>
            </li>
            <li class="nav-item">
                <a class="nav-link"  href="feedback.php">Feedback</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="search.php">Search</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="myDocs.php">MyFiles</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="login.php">Log Out</a>
            </li>
        </ul>

        <p style="color:silver" class="navbar-nav"> Current User: <?php echo $user ?> </p>
    </nav>

</head>

<body>
<div class="container">
     
        <h1 style="text-align:center;"> </h1>
        <h1 style="text-align:center;"> </h1>
        <h1 style="text-align:center;"> </h1>
        <h1 class="display-1" style="text-align:center;">Welcome to StudyBuddies Document Information Viewer</h1>
        <h1 style="text-align:center;"> </h1>
        <h4 style="text-align:center;">Please Click on the Navbar Links Above to Get Started</h1>
</div>

</body>

</html>