<?php
session_start(); // start session
require('connectdbUser.php'); // connect to database
$user = $_SESSION['User'];
global $db;


if (isset($_POST['ascDoc'])) {
    $sql = "SELECT docName, userEmail, courseID, subject, type, numCards, maxScore from document ORDER BY docName ASC"; // sorts results by document name in ascending order
}
else if (isset($_POST['descDoc'])) {
    $sql = "SELECT docName, userEmail, courseID, subject, type, numCards, maxScore from document ORDER BY docName DESC"; // sorts results by document name in descending order
}
else if (isset($_POST['ascSubject'])) {
    $sql = "SELECT docName, userEmail, courseID, subject, type, numCards, maxScore from document ORDER BY subject ASC"; // sorts results by subject name in ascending order
}
else if (isset($_POST['descSubject'])) {
    $sql = "SELECT docName, userEmail, courseID, subject, type, numCards, maxScore from document ORDER BY subject DESC"; // sorts results by subject name in descending order
}
else if (isset($_POST['ascCards'])) {
    $sql = "SELECT docName, userEmail, courseID, subject, type, numCards, maxScore from document ORDER BY numCards ASC"; // sorts results by numCards in ascending order
}
else if (isset($_POST['descCards'])) {
    $sql = "SELECT docName, userEmail, courseID, subject, type, numCards, maxScore from document ORDER BY numCards DESC"; // sorts results by numCards  in descending order
}
else if (isset($_POST['searchButton'])) {
    $sql = 'SELECT docName, userEmail, courseID, subject, type, numCards, maxScore from document WHERE docName LIKE "%' . $_POST['searchText'] . '%"'; // only shows results that have a document name relating to the search box input
}
else{
    $sql = "SELECT docName, userEmail, courseID, subject, type, numCards, maxScore from document";
}

$result = $db->query($sql);
 


?>


<!-- HTML Code -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="your name">
    <meta name="description" content="include some description about your page">
    <title>DB interfacing</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <style>
        div {
            margin-bottom: 10px;
        }

        label {
            display: inline-block;
            width: 150px;
            text-align: right;
        }
    </style>

    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="docUpload.php">Upload</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="feedback.php">Feedback</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="search.php">Search</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="myDocs.php">MyFiles</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="login.php">Log Out</a>
            </li>
        </ul>
        <p style="color:silver" class="navbar-nav"> Current User: <?php echo $user ?> </p>
    </nav>

</head>

<body>
    <div class="container">

        <h1>Document List</h1>



        <form name="mainForm" action="search.php" method="post">
                <div class="form-group">
                    <div class="input-group">
                        <!-- Search Bar -->
                        <input class="form-control" name="searchText" placeholder="Search for document..." type="text">
                        <span class="input-group-btn">
                            <input type="submit" name="searchButton" value="Go!" class="btn btn-success"/>
                        </span>
                    </div>
                </div>

                <!-- Sorting Buttons -->
            <h4>Sort By: Document
                <input type="submit" value="Asc" name="ascDoc" class="btn btn-primary btn-sm" />
                <input type="submit" value="Desc" name="descDoc" class="btn btn-primary btn-sm" />⠀|
                Subject
                <input type="submit" value="Asc" name="ascSubject" class="btn btn-primary btn-sm" />
                <input type="submit" value="Desc" name="descSubject" class="btn btn-primary btn-sm" />⠀|
                Cards
                <input type="submit" value="Asc" name="ascCards" class="btn btn-primary btn-sm" />
                <input type="submit" value="Desc" name="descCards" class="btn btn-primary btn-sm" />
            </h4>
        </form>

        <!-- Table -->
        <table class="w3-table w3-bordered w3-card-4 center" style="width:70%">
            <thead>
                <tr style="background-color:#B0B0B0">
                    <th width="25%">Document</th>
                    <th width="25%">Owner</th>
                    <th width="25%">CourseID</th>
                    <th width="25%">Subject</th>
                    <th width="25%">Type</th>
                    <th width="25%">Cards</th>
                    <th width="25%">Max Score</th>
                </tr>
            </thead>

            <?php

           

            // iteratively displays results based on search done in php code at top of file
            while ($row = $result->fetch()) {
                echo "<tr><td>" . $row["docName"] . "</td><td>" . $row["userEmail"] . "</td><td>" . $row["courseID"] . "</td><td>" . $row["subject"] . "</td><td>" . $row["type"] . "</td><td>" . $row["numCards"] . "</td><td>" . $row["maxScore"] . "</td>";
                echo '</tr>';
            }

            ?>

</body>

</html>