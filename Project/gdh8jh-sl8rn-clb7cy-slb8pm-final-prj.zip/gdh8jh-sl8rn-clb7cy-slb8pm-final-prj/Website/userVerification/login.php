<?php
session_start(); // starts session
require('connectdb.php'); // connects to database
$username = "";
$password = "";
$errors = array(); // array that's used to contain a list of error messages
$found = 0; // used to check if user in database or found or not. 0 means not found and 1 means found

// activates when login button is rpessed
if (isset($_POST['login-btn'])) {
    $errors = array();
    
    // checks for empty username field
    if (empty($_POST['username'])) {
        $errors['username'] = "Username required";
    }
    $found = 0;

    // check to see if user exists in database
    global $db;
    $sql = "SELECT userEmail, password from users";
    $result = $db->query($sql);

    while ($row = $result->fetch()) {

        // if user does exist then break, if not keep looking until reach end
        if ($row["userEmail"] == $_POST['username']) {
            $found = 1;
            break;
        }
    }

    // check if users exists or not by looking at found variable
    if ($found == 0) {
        //if user does not exist then stay on page and store error message in array
        $errors['notFound'] = "Account Not Found";
    } else {
        // if user does exist assign user to session and redirect to main website page
        $_SESSION['User'] = $_POST['username'];
        $_SESSION['Password'] = $_POST['password'];
        header("Location: index.php");
    }
}
?>


<!-- HTML Code -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Login</title>

</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4 form-div login">
                <form action="login.php" method="post">
                    <h3 class="text-center">Login</h3>

                    <!-- php code that iterively displays error messages when the user has submitted form with problems-->
                    <?php if (count($errors) > 0) : ?>
                        <div class="alert alert-danger">
                            <?php foreach ($errors as $error) : ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="username">Username or Email</label>
                        <input type="text" name="username" 
                        value="<?php echo $username ?>" class="form-control form-control-lg">
                    </div>


                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password"
                         value="<?php echo $password ?>" class="form-control form-control-lg">
                    </div>


                    <div class="form-group">
                        <button type="submit" name="login-btn" class="btn btn-primary btn-block btn-lg">Login</button>
                    </div>

                    <p class="text-center"> Not a member? <a href="signUp.php"> Sign up </a></p>

                </form>
            </div>
        </div>
    </div>

</body>

</html>