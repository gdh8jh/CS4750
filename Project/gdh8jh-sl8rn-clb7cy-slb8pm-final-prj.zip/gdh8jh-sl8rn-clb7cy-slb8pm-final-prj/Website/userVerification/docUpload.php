<?php
session_start(); // start session
require('connectdbUser.php'); // connects user to database


$user = $_SESSION['User']; // assigns user to variable

// list of variables used for php functions
$docName = ""; // 
$fileType = "";
$fileSize = 0;
$fileID = 0;
$courseID = 0;
$subject = "";
$popularityRank = 0;
$numViews = 0;
$numCards = 0;
$type = "";
$maxScore = 0;
$courseID = "";

//activates code inside when user submits their document details
if (isset($_POST['submitDoc'])) { 
    global $db;

    // inserts relavent document info into the technical_info table
    $query = 'INSERT INTO technical_info (docName, fileType, fileSize) 
              VALUES ("' . $_POST['docName'] . '", "' . $_POST['fileType'] . '", ' .  $_POST['fileSize'] . ')'; 
    $statement = $db->query($query);

    // retrieves the latest row in the technical_info table, so that latest fileID can be retrieved
    $sql = 'SELECT fileID 
            FROM technical_info
            WHERE docName = "' . $_POST['docName'] . '" AND fileType ="' . $_POST['fileType'] . '"
            ORDER BY fileID DESC Limit 1';
    $result = $db->query($sql);
    while ($row = $result->fetch()) {
        $fileID = $row["fileID"];
    }


    // inserts remaining relevant values into document table
    $query = 'INSERT INTO document 
              VALUES ("' . $_POST['docName'] . '", "' . $user . '", ' .  $fileID . ', ' . $_POST['courseID'] . ', "' . $_POST['subject'] . '", ' . $popularityRank . ', ' . $numViews . ', ' . $_POST['numCards'] . ', "' . $_POST['type'] . '", ' . $_POST['maxScore'] . ')';
    $statement = $db->query($query);


}



?>


<!-- HTML Code -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="author" content="your name">
  <meta name="description" content="include some description about your page">
  <title>DB interfacing</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">


  <!-- Navbar -->
  <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="docUpload.php">Upload</a>
            </li>
            <li class="nav-item">
                <a class="nav-link"  href="feedback.php">Feedback</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="search.php">Search</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="myDocs.php">MyFiles</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="login.php">Log Out</a>
            </li>
        </ul>

        <p style="color:silver" class="navbar-nav"> Current User: <?php echo $user ?> </p>
    </nav>

</head>

<body>
  <div class="container">

    <h1>Please Type in Document Information</h1>
    <h4>Note: Available Course IDs are 12, 23, 34, 45, 56, 67, 78, 89, 90, 91, 92, 93, 94
      95, 96, 97, 98, 99, 100, 101
    </h4>
    <!-- Form. Contains different sections for the different parts of the information relating to the document  -->
    <form name="mainForm" action="docUpload.php" method="post">
      <div class="form-group">
        Document Name:
        <input type="text" class="form-control" name="docName" />
      </div>
      <div class="form-group">
        File Type (.pdf, .docx, etc...):
        <input type="text" class="form-control" name="fileType" />
      </div>
      <div class="form-group">
        File Size (100, 200, 3000, etc...):
        <input type="text" class="form-control" name="fileSize" />
      </div>
      <div class="form-group">
        Subject (Biology, Math, Chemistry, etc...):
        <input type="text" class="form-control" name="subject" />
      </div>
      <div class="form-group">
        Course ID:
        <input type="text" class="form-control" name="courseID" />
      </div>
      <div class="form-group">
        Document Type (Quiz or Flashcards):
        <input type="text" class="form-control" name="type" />
      </div>
      <div class="form-group">
        Max Achieveable Score (if not applicable put 0):
        <input type="text" class="form-control" name="maxScore" />
      </div>
      <div class="form-group">
        Number of cards (if not applicable to document put 0):
        <input type="text" class="form-control" name="numCards" />
      </div>

      <input type="submit" value="Submit Document Information" name="submitDoc" class="btn btn-dark" title="Confirm update a friend" />

    </form>

</body>

</html>