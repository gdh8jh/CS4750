-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2020 at 12:26 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studybuddy`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `storeFeedback` (IN `admID` INT, `myCom` VARCHAR(255), `email` VARCHAR(255))  BEGIN
INSERT INTO feedback (adminID, comment, userEmail)
VALUES (admID, myCom, email);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `adminID` int(11) NOT NULL,
  `adminName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`adminID`, `adminName`) VALUES
(1, 'geoff'),
(2, 'christian'),
(3, 'sammy'),
(4, 'sam'),
(5, 'Cersei Lannister'),
(6, 'Petyr Baelish'),
(7, 'Loras Tyrell'),
(8, 'Jon Snow'),
(9, 'Bars Mars'),
(10, 'Sing Dung'),
(11, 'Terence Owens'),
(12, 'Victor Smith'),
(13, 'Leo Armstrong'),
(14, 'Ernest Snyder'),
(15, 'Neil Harvey'),
(16, 'Heidi Walker'),
(17, 'Delores Montgomery'),
(18, 'Ray Johnston'),
(19, 'Velma Mitchell'),
(20, 'Marcella Harper');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `courseID` int(11) NOT NULL,
  `profID` int(11) DEFAULT NULL,
  `courseInfo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`courseID`, `profID`, `courseInfo`) VALUES
(12, 9101, 'test course info 1'),
(23, 9109, 'test course info 2'),
(34, 9103, 'test course info 3'),
(45, 9104, 'test course info 4'),
(56, 9105, 'test course info 5'),
(67, 9106, 'test course info 6'),
(78, 9107, 'test course info 7'),
(89, 9108, 'test course info 8'),
(90, 9109, 'test course info 9'),
(91, 9110, 'test course info 10'),
(92, 9111, 'test course info 11'),
(93, 9112, 'test course info 12'),
(94, 9113, 'test course info 13'),
(95, 9114, 'test course info 14'),
(96, 9115, 'test course info 15'),
(97, 9116, 'test course info 16'),
(98, 9117, 'test course info 17'),
(99, 9118, 'test course info 18'),
(100, 9119, 'test course info 19'),
(101, 9120, 'test course info 20');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `depName` varchar(255) NOT NULL,
  `depHead` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`depName`, `depHead`) VALUES
('African Studies', 'Perky'),
('Anthropology', 'Borat'),
('Bioethics', 'Sherman'),
('Biology', 'Nye'),
('Chemistry', 'Bushwack'),
('Classics', 'Gradely'),
('Commerce', 'Mccintire'),
('Computer Science', 'Upsorn'),
('Disability Studies', 'Shingler'),
('Drama', 'Bush'),
('French', 'Tungle'),
('Global Studies - Environments and Sustainability', 'Derpan'),
('Global Studies - Security and Justice', 'Hurtly'),
('Jewish Studies', 'Dangly'),
('Linguistics', 'Mertkins'),
('Math', 'Garland'),
('Medieval Studies', 'Fantam'),
('Mixology', 'Boylan'),
('Music', 'Vert'),
('Philosophy', 'Derpan'),
('Religion', 'Minor');

-- --------------------------------------------------------

--
-- Table structure for table `document`
--

CREATE TABLE `document` (
  `docName` varchar(255) NOT NULL,
  `userEmail` varchar(255) DEFAULT NULL,
  `fileID` int(11) DEFAULT NULL,
  `courseID` int(11) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `popularityRank` int(11) DEFAULT NULL,
  `numViews` int(11) DEFAULT NULL,
  `numCards` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `maxScore` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `document`
--

INSERT INTO `document` (`docName`, `userEmail`, `fileID`, `courseID`, `subject`, `popularityRank`, `numViews`, `numCards`, `type`, `maxScore`) VALUES
('ANTH1200 EXAM 1 2014', 'teverett@verizon.net', 22, 93, 'French', 13, 82, 37, 'flashcards', 78),
('ANTH3102 MIDTERM 2019', 'al9bv@gmail.com', 4, 12, 'Anthropology', 44, 129, 27, 'quiz', 89),
('BIO5678 EXAM 1 2014', 'teverett@verizon.net', 19, 100, 'French', 13, 82, 37, 'quiz', 78),
('CHEM2422 MIDTERM 2015', 'as2ew@gmail.com', 16, 97, 'Music', 9, 33, 26, 'quiz', 64),
('CHEM5600 EXAM 2 2019', 'rgarcia@icloud.com', 20, 101, 'Classics', 27, 56, 18, 'quiz', 76),
('CLAS2234 EXAM 2 2019', 'rgarcia@icloud.com', 10, 91, 'Classics', 27, 56, 18, 'quiz', 76),
('COMM3240 FINAL 2020', 'my9ed@gmail.com', 15, 96, 'Commerce', 3, 480, 38, 'quiz', 88),
('COMM4780 FINAL 2020', 'my9ed@gmail.com', 5, 56, 'Commerce', 3, 480, 38, 'quiz', 88),
('COMM5102 MIDTERM 2019', 'al9bv@gmail.com', 14, 95, 'Anthropology', 44, 129, 27, 'flashcards', 89),
('CS2102 EXAM 2 2019', 'up1wb@gmail.com', 8, 89, 'Computer Science', 27, 56, 18, 'flashcards', 76),
('CS2150 EXAM 2 2011', 'cp3rf@gmail.com', 1, 45, 'Computer Science', 5, 237, 25, 'quiz', 99),
('CS4102 EXAM 1 2009', 'my9ed@gmail.com', 2, 34, 'Computer Science', 1, 331, 21, 'flashcards', 96),
('CS4500 EXAM 2 2019', 'rgarcia@icloud.com', 23, 94, 'Classics', 27, 56, 18, 'quiz', 76),
('CS4750 FINAL EXAM 2016', 'jd7fs@gmail.com', 3, 23, 'Computer Science', 17, 48, 19, 'flashcards', 75),
('CS4800 FINAL EXAM 2016', 'jd7fs@gmail.com', 13, 94, 'Computer Science', 17, 48, 19, 'quiz', 75),
('DIS3000 EXAM 1 2009', 'my9ed@gmail.com', 12, 93, 'Computer Science', 1, 331, 21, '.quiz', 96),
('FREN1000 EXAM 1 2014', 'teverett@verizon.net', 9, 90, 'French', 13, 82, 37, 'quiz', 78),
('FREN1100 EXAM 2 2019', 'up1wb@gmail.com', 18, 99, 'Computer Science', 27, 56, 18, 'flashcards', 76),
('JWS4005 EXAM 2 2011', 'cp3rf@gmail.com', 11, 92, 'Computer Science', 5, 237, 25, 'flashcards', 99),
('MATH2102 EXAM 1 2014', 'cn6er@gmail.com', 7, 78, 'Mathematics', 13, 82, 37, 'flashcards', 78),
('MATH3023 EXAM 2 2019', 'up1wb@gmail.com', 21, 92, 'Computer Science', 27, 56, 18, 'flashcards', 76),
('MUSI3400 EXAM 1 2014', 'cn6er@gmail.com', 17, 98, 'Mathematics', 13, 82, 37, 'flashcards', 78),
('MUSI3550 MIDTERM 2015', 'as2ew@gmail.com', 6, 67, 'Music', 9, 33, 26, 'quiz', 64);

--
-- Triggers `document`
--
DELIMITER $$
CREATE TRIGGER `makeDocAllCaps` BEFORE INSERT ON `document` FOR EACH ROW set new.docName = UPPER(new.docName)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedID` int(11) NOT NULL,
  `adminID` int(11) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `userEmail` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedID`, `adminID`, `comment`, `userEmail`) VALUES
(1, 1, 'Nice website', 'cp3rf@gmail.com'),
(2, 2, 'Website sucks', 'jd7fs@gmail.com'),
(3, 3, 'Website could have better functionality', 'my9ed@gmail.com'),
(4, 4, 'The site rocks', 'al9bv@gmail.com'),
(5, 5, 'I think the site could improve its login page', 'po2nm@gmail.com'),
(6, 6, 'Worst site Ive ever used', 'cn6er@gmail.com'),
(7, 7, 'Good stuff guys', 'as2ew@gmail.com'),
(8, 8, 'This is the best website Ive ever used', 'up1wb@gmail.com'),
(9, 9, 'Very Cool', 'teverett@verizon.net'),
(10, 10, 'I like it', 'rgarcia@icloud.com'),
(11, 11, 'Good Stuff', 'dhwon@yahoo.ca'),
(12, 12, 'neato guys', 'mcrawfor@aol.com'),
(13, 13, 'best website ever', 'melnik@comcast.net'),
(14, 14, 'good job everyone', 'wildfire@yahoo.com'),
(15, 15, 'can I pay for this?', 'airship@sbcglobal.net'),
(16, 16, 'big stuff guys', 'enintend@me.com'),
(17, 17, 'epic', 'chlim@gmail.com'),
(18, 18, 'cant wait to show mom', 'citadel@icloud.com'),
(19, 19, 'my sister thinks its cool', 'mddallara@hotmail.com'),
(20, 20, 'I dont like it', 'somestuff@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `professor`
--

CREATE TABLE `professor` (
  `profID` int(11) NOT NULL,
  `depName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `professor`
--

INSERT INTO `professor` (`profID`, `depName`, `lastName`) VALUES
(9101, 'Computer Science', 'Wahoowa'),
(9102, 'Computer Science', 'Sheriff'),
(9103, 'Computer Science', 'Upsorn'),
(9104, 'Computer Science', 'Dogg'),
(9105, 'Computer Science', 'Cat'),
(9106, 'Anthropology', 'Borat'),
(9107, 'Commerce', 'Mccintire'),
(9108, 'Music', 'Vert'),
(9109, 'Computer Science', 'Wahoowa'),
(9110, 'French', 'Hopkins'),
(9111, 'Chemistry', 'Merkel'),
(9112, 'Jewish Studies', 'Hobbs'),
(9113, 'Classics', 'Perk'),
(9114, 'Computer Science', 'Dongle'),
(9115, 'Math', 'Bingle'),
(9116, 'Anthropology', 'Bop'),
(9117, 'Commerce', 'Slurp'),
(9118, 'Music', 'Furp'),
(9119, 'Computer Science', 'Kirk'),
(9120, 'French', 'Slapkins');

-- --------------------------------------------------------

--
-- Table structure for table `supportstaff`
--

CREATE TABLE `supportstaff` (
  `supportID` int(11) NOT NULL,
  `supportEmail` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supportstaff`
--

INSERT INTO `supportstaff` (`supportID`, `supportEmail`) VALUES
(1, 'ixesicybi-5804@yopmail.com'),
(2, 'cerinneppus-4737@yopmail.com'),
(3, 'addiwomemmo-1620@yopmail.com'),
(4, 'wonnaruwo-9500@yopmail.com'),
(5, 'ekuloturr-2300@yopmail.com'),
(6, 'ullipacih-1021@yopmail.com'),
(7, 'ittussedduw-2281@yopmail.com'),
(8, 'beqopepuc-0820@yopmail.com'),
(9, 'annexery-7325@yopmail.com'),
(10, 'anycasso-5596@yopmail.com'),
(11, 'yppossijyffu-1701@yopmail.com'),
(12, 'elillurry-5004@yopmail.com'),
(13, 'uppuddolex-2799@yopmail.com'),
(14, 'tuppisefes-4114@yopmail.com'),
(15, 'qeddappaffodd-2277@yopmail.com'),
(16, 'utosommat-2723@yopmail.com'),
(17, 'ossedanne-2300@yopmail.com'),
(18, 'jazucanaje-9321@yopmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `supportstaff_phone`
--

CREATE TABLE `supportstaff_phone` (
  `phone` varchar(255) NOT NULL,
  `supportID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supportstaff_phone`
--

INSERT INTO `supportstaff_phone` (`phone`, `supportID`) VALUES
('434-382-9466', 1),
('925-948-9693', 2),
('606-304-3781', 3),
('973-241-2586', 4),
('530-280-4934', 5),
('713-960-6875', 6),
('408-373-4427', 7),
('704-752-6158', 8),
('435-374-1890', 9),
('801-592-4294', 10),
('801-401-8525', 11),
('801-351-8395', 12),
('801-690-5352', 13),
('801-964-2324', 14),
('435-669-2241', 15),
('801-392-0678', 16),
('801-474-7362', 17),
('435-542-5805', 18);

-- --------------------------------------------------------

--
-- Table structure for table `technical_info`
--

CREATE TABLE `technical_info` (
  `fileID` int(11) NOT NULL,
  `docName` varchar(255) NOT NULL,
  `fileType` varchar(255) DEFAULT NULL,
  `fileSize` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `technical_info`
--

INSERT INTO `technical_info` (`fileID`, `docName`, `fileType`, `fileSize`) VALUES
(1, 'CS2150 Exam 2 2011', '.doc', 213),
(2, 'CS4102 Exam 1 2009', '.pdf', 1445),
(3, 'CS4750 Final Exam 2016', '.docx', 24),
(4, 'ANTH3102 Midterm 2019', '.png', 678),
(5, 'COMM4780 Final 2020', '.pdf', 258),
(6, 'MUSI3550 Midterm 2015', '.doc', 45),
(7, 'MATH2102 Exam 1 2014', '.html', 98),
(8, 'CS2102 Exam 2 2019', '.py', 876),
(9, 'FREN1000 Exam 1 2014', '.html', 98),
(10, 'CLAS2234 Exam 2 2019', '.py', 876),
(11, 'JWS4005 Exam 2 2011', '.doc', 213),
(12, 'DIS3000 Exam 1 2009', '.pdf', 1445),
(13, 'CS4800 Final Exam 2016', '.docx', 24),
(14, 'COMM5102 Midterm 2019', '.png', 678),
(15, 'COMM3240 Final 2020', '.pdf', 258),
(16, 'CHEM2422 Midterm 2015', '.doc', 45),
(17, 'MUSI3400 Exam 1 2014', '.html', 98),
(18, 'FREN1100 Exam 2 2019', '.py', 876),
(19, 'BIO5678 Exam 1 2014', '.html', 98),
(20, 'CHEM5600 Exam 2 2019', '.py', 876),
(21, 'MATH3023 Exam 2 2019', '.py', 876),
(22, 'ANTH1200 Exam 1 2014', '.html', 98),
(23, 'CS4500 Exam 2 2019', '.py', 876);

-- --------------------------------------------------------

--
-- Table structure for table `userprofiles`
--

CREATE TABLE `userprofiles` (
  `profileID` int(11) NOT NULL,
  `userEmail` varchar(255) DEFAULT NULL,
  `major` varchar(255) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `compID` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userprofiles`
--

INSERT INTO `userprofiles` (`profileID`, `userEmail`, `major`, `DOB`, `compID`, `first_name`, `last_name`) VALUES
(1, 'cp3rf@gmail.com', 'biology', '1998-02-02', 'gdh8jh', 'Geoff', 'Hicks'),
(2, 'jd7fs@gmail.com', 'history', '1998-06-02', 'xyz9jk', 'Mark', 'Finkle'),
(3, 'my9ed@gmail.com', 'biology', '1997-06-12', 'zdb9dg', 'Hans', 'Zeimerman'),
(4, 'al9bv@gmail.com', 'computer science', '1998-01-04', 'bpo7hj', 'Biff', 'Perkins'),
(5, 'po2nm@gmail.com', 'philosophy', '1997-03-08', 'shd3kj', 'Shelly', 'Dillard'),
(6, 'cn6er@gmail.com', 'philosophy', '1999-02-05', 'sjd2kl', 'Sally', 'Jenkins'),
(7, 'as2ew@gmail.com', 'chemistry', '2000-07-10', 'cst5jk', 'Chad', 'Sticks'),
(8, 'up1wb@gmail.com', 'chemistry', '1995-03-09', 'khv2dj', 'Katrina', 'Herr'),
(9, 'teverett@verizon.net', 'chemistry', '2000-02-10', 'ghj8kj', 'Dan', 'Sticks'),
(10, 'rgarcia@icloud.com', 'history', '1993-03-10', 'kmn8jk', 'Kali', 'Banks'),
(11, 'dhwon@yahoo.ca', 'math', '1992-03-02', 'dvh7jh', 'Deevon', 'Juk'),
(12, 'mcrawfor@aol.com', 'history', '1995-06-02', 'bgh0kl', 'Big', 'Gurk'),
(13, 'melnik@comcast.net', 'philosophy', '1992-02-02', 'sdf5bh', 'Sam', 'Zeimerman'),
(14, 'wildfire@yahoo.com', 'computer science', '1998-03-04', 'bfg4hj', 'Bing', 'Bop'),
(15, 'airship@sbcglobal.net', 'philosophy', '1997-03-03', 'gbd3ds', 'Garret', 'Dillard'),
(16, 'enintend@me.com', 'philosophy', '1999-02-04', 'gds2df', 'Gerd', 'Merk'),
(17, 'chlim@gmail.com', 'math', '2000-07-11', 'gds8kl', 'Gedfe', 'Herf'),
(18, 'citadel@icloud.com', 'math', '1995-02-09', 'dsg2nm', 'Dan', 'Herr'),
(19, 'mddallara@hotmail.com', 'computer science', '2000-08-10', 'dgs4ds', 'Danny', 'Bigs'),
(20, 'somestuff@gmail.com', 'history', '1993-01-10', 'gds2hn', 'Kali', 'Richards'),
(21, 'nwiger@att.net', 'biology', '1998-02-04', 'jgf3gf', 'Jerman', 'Hicks'),
(22, 'gilmoure@aol.com', 'history', '1998-06-03', 'hfd3ds', 'Handle', 'Finkle'),
(23, 'sburke@yahoo.ca', 'biology', '1997-06-11', 'gds3hg', 'Gertrude', 'Zeimerman'),
(24, 'kingjoshi@outlook.com', 'computer science', '1994-01-04', 'dsg2hg', 'Slam', 'Perkins'),
(25, 'tbeck@yahoo.com', 'philosophy', '1992-03-08', 'dsa2ds', 'Derkin', 'Dillard'),
(26, 'hoangle@me.com', 'philosophy', '1999-02-05', 'hon2ds', 'Ho', 'Ming'),
(27, 'bdbrown@hotmail.com', 'chemistry', '2000-02-10', 'dsf6jh', 'Jan', 'Pho'),
(28, 'eabrown@optonline.net', 'chemistry', '1995-01-09', 'gds2hj', 'Gad', 'Mickal'),
(29, 'qmacro@sbcglobal.net', 'chemistry', '2001-02-10', 'gff3ds', 'Gabby', 'Sticks'),
(30, 'damian@sbcglobal.net', 'history', '1993-03-11', 'kmn8jk', 'Car', 'Matty');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userEmail` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `supportID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userEmail`, `password`, `supportID`) VALUES
('airship@sbcglobal.net', 'sdagasdg', 5),
('al9bv@gmail.com', 'pih7g!', 4),
('as2ew@gmail.com', 'ihgpi5!', 7),
('bdbrown@hotmail.com', 'dsgsgc', 7),
('chlim@gmail.com', 'dasgasdga', 7),
('citadel@icloud.com', 'dsagasgg', 8),
('cn6er@gmail.com', 'oh4f3!', 6),
('cp3rf@gmail.com', 'h4u5ht!', 1),
('damian@sbcglobal.net', 'ghkghk', 10),
('dhwon@yahoo.ca', 'dsgsdgs', 1),
('eabrown@optonline.net', 'ewgsgd', 8),
('enintend@me.com', 'agdgas', 6),
('gilmoure@aol.com', 'sdafasf', 2),
('hoangle@me.com', 'gfgjf', 6),
('jd7fs@gmail.com', '2oihg!', 2),
('kingjoshi@outlook.com', '3dsgs', 4),
('mcrawfor@aol.com', 'asgsa', 2),
('mddallara@hotmail.com', 'sgagdasg', 9),
('melnik@comcast.net', 'dsagasdg', 3),
('my9ed@gmail.com', 'oi5gf!', 3),
('nwiger@att.net', 'dfsgdfs', 1),
('po2nm@gmail.com', 'ou1fg!', 5),
('qmacro@sbcglobal.net', 'jgfhf', 9),
('rgarcia@icloud.com', 'pif4pp!', 10),
('sburke@yahoo.ca', 'fdshsdfh', 3),
('somestuff@gmail.com', 'dgsgasdg', 10),
('tbeck@yahoo.com', 'gdscsd', 5),
('teverett@verizon.net', 'ihgpi5!', 9),
('up1wb@gmail.com', 'pif4pp!', 8),
('wildfire@yahoo.com', 'asdgasd', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`courseID`),
  ADD KEY `profID` (`profID`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`depName`);

--
-- Indexes for table `document`
--
ALTER TABLE `document`
  ADD PRIMARY KEY (`docName`),
  ADD KEY `userEmail` (`userEmail`),
  ADD KEY `courseID` (`courseID`),
  ADD KEY `FK_document_techInfo` (`fileID`,`docName`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedID`),
  ADD KEY `adminID` (`adminID`),
  ADD KEY `userEmail` (`userEmail`);

--
-- Indexes for table `professor`
--
ALTER TABLE `professor`
  ADD PRIMARY KEY (`profID`),
  ADD KEY `depName` (`depName`);

--
-- Indexes for table `supportstaff`
--
ALTER TABLE `supportstaff`
  ADD PRIMARY KEY (`supportID`);

--
-- Indexes for table `supportstaff_phone`
--
ALTER TABLE `supportstaff_phone`
  ADD PRIMARY KEY (`supportID`,`phone`);

--
-- Indexes for table `technical_info`
--
ALTER TABLE `technical_info`
  ADD PRIMARY KEY (`fileID`,`docName`);

--
-- Indexes for table `userprofiles`
--
ALTER TABLE `userprofiles`
  ADD PRIMARY KEY (`profileID`),
  ADD KEY `userEmail` (`userEmail`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userEmail`),
  ADD KEY `supportID` (`supportID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrator`
--
ALTER TABLE `administrator`
  MODIFY `adminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `courseID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `professor`
--
ALTER TABLE `professor`
  MODIFY `profID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9121;

--
-- AUTO_INCREMENT for table `supportstaff`
--
ALTER TABLE `supportstaff`
  MODIFY `supportID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `technical_info`
--
ALTER TABLE `technical_info`
  MODIFY `fileID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `userprofiles`
--
ALTER TABLE `userprofiles`
  MODIFY `profileID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `course_ibfk_1` FOREIGN KEY (`profID`) REFERENCES `professor` (`profID`);

--
-- Constraints for table `document`
--
ALTER TABLE `document`
  ADD CONSTRAINT `FK_document_techInfo` FOREIGN KEY (`fileID`,`docName`) REFERENCES `technical_info` (`fileID`, `docName`),
  ADD CONSTRAINT `document_ibfk_1` FOREIGN KEY (`userEmail`) REFERENCES `users` (`userEmail`),
  ADD CONSTRAINT `document_ibfk_2` FOREIGN KEY (`courseID`) REFERENCES `course` (`courseID`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`adminID`) REFERENCES `administrator` (`adminID`),
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`userEmail`) REFERENCES `users` (`userEmail`);

--
-- Constraints for table `professor`
--
ALTER TABLE `professor`
  ADD CONSTRAINT `professor_ibfk_1` FOREIGN KEY (`depName`) REFERENCES `department` (`depName`);

--
-- Constraints for table `userprofiles`
--
ALTER TABLE `userprofiles`
  ADD CONSTRAINT `userprofiles_ibfk_1` FOREIGN KEY (`userEmail`) REFERENCES `users` (`userEmail`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`supportID`) REFERENCES `supportstaff` (`supportID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
